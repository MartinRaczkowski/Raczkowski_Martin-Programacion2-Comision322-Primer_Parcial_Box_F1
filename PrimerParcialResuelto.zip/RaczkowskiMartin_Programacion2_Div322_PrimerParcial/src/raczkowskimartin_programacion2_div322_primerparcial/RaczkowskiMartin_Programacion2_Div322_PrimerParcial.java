package raczkowskimartin_programacion2_div322_primerparcial;

public class RaczkowskiMartin_Programacion2_Div322_PrimerParcial {

    public static void main(String[] args) {
        
        InventarioBox ferrariBox = new InventarioBox("Box de Ferrari");
        
        Motor motor1 = new Motor("PU-016", "Taller", CondicionClimatica.SECO, 500);
        Ala ala1 = new Ala("Ala 1", "Estacion aero", CondicionClimatica.MIXTO, 8);
        Neumatico neumatico1 = new Neumatico(Compuesto.MEDIUM, "Neumatico 1", "Carro de neumaticos", CondicionClimatica.SECO);
        
        
        try{
            ferrariBox.agregarPieza(motor1);
            ferrariBox.agregarPieza(ala1);
            ferrariBox.agregarPieza(neumatico1);
            ferrariBox.agregarPieza(motor1);
        }
        catch(PiezaDuplicadaException exc){
            System.out.println(exc.getMessage());
        }
        
        ferrariBox.mostrarPiezas();
        
        ferrariBox.ajustarPiezas();
        
        System.out.println(ferrariBox.buscarPiezaPorCondicionClimatica(CondicionClimatica.SECO));
        System.out.println(ferrariBox.buscarPiezaPorCondicionClimatica(CondicionClimatica.LLUVIA));
    }
    
}
