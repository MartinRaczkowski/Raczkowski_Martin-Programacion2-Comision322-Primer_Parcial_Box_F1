package raczkowskimartin_programacion2_div322_primerparcial;


public class PiezaDuplicadaException extends Exception{
    
    private static final String MESSAGE = "Pieza duplicada";
    
    public PiezaDuplicadaException(){
        super(MESSAGE);
    }

    public static String getMESSAGE() {
        return MESSAGE;
    }
    
}
