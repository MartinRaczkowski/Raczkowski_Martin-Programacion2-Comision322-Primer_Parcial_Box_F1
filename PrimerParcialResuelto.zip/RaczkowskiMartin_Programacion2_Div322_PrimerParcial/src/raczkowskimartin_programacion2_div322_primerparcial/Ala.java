
package raczkowskimartin_programacion2_div322_primerparcial;

public class Ala extends Pieza implements Ajustable{
    
    private int cargaAerodinamica;
    private static final double minCargaAero = 1;
    private static final double maxCargaAero = 10;

    public Ala(String nombre, String ubicacionDelBox, CondicionClimatica mejorCondicionClimatica, int cargaAerodinamica) {
        super(nombre, ubicacionDelBox, mejorCondicionClimatica);
        validarCargaAero(cargaAerodinamica);
        this.cargaAerodinamica = cargaAerodinamica;
    }
    
    private void validarCargaAero(int carga){
        if(carga < minCargaAero || carga > maxCargaAero){
            throw new IllegalArgumentException("Carga aerodinamica fuera de los limites");
        }
    }

    public int getCargaAerodinamica() {
        return cargaAerodinamica;
    }

    @Override
    public void ajustar(){
        System.out.println("Se ajusta el ala");
    }
    
    @Override
    public String toString(){
        return super.toString() + ", carga aerodinamica: " + cargaAerodinamica;
    }
    
}
