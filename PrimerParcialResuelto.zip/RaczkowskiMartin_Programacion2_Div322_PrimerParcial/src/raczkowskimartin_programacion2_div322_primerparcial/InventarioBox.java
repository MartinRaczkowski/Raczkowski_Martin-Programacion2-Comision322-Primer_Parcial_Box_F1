package raczkowskimartin_programacion2_div322_primerparcial;

import java.util.ArrayList;

public class InventarioBox {
    
    private String nombre;
    private ArrayList<Pieza> piezas;

    public InventarioBox(String nombre) {
        this.nombre = nombre;
        piezas = new ArrayList<>();
    }
    
    public void agregarPieza(Pieza pieza) throws PiezaDuplicadaException{
        if(pieza == null){
            throw new IllegalArgumentException();
        }
        if(piezas.contains(pieza)){
            throw new PiezaDuplicadaException();
        }
        piezas.add(pieza);
        System.out.println("Se agrego la pieza: " + pieza);
    }
    
    public void mostrarPiezas(){
        StringBuilder lista = new StringBuilder();
        lista.append("Piezas: ");
        for(Pieza p : piezas){
            lista.append("\n" + p );
        }
        System.out.println(lista.toString());
    }
    
    public void ajustarPiezas(){
        for(Pieza p : piezas){
            if(p instanceof Ajustable a){
                a.ajustar();
            }
            else{
                System.out.println(p.getNombre() + " no se ajustan");
            }
        }
    }
    
    public String buscarPiezaPorCondicionClimatica(CondicionClimatica condicion){
        StringBuilder lista = new StringBuilder();
        int i = 0;
        for(Pieza p : piezas){
            if(p.getMejorClima() == condicion){
                lista.append(p);
                i++;
            }
        }
        if(i > 0){
            return "Se encontraron las siguiente piezas con la condicion indicada:\n" + lista.toString();
        }else{
            return "No se encontraron piezas con la condicion climatica " + condicion;
        }
    }
    
    
    
}
