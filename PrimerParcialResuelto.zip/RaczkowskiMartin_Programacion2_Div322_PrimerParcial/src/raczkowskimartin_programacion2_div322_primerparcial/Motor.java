
package raczkowskimartin_programacion2_div322_primerparcial;


public class Motor extends Pieza implements Ajustable {
    
    private int potenciaMaximaCV;
    

    public Motor(String nombre, String ubicacionDelBox, CondicionClimatica mejorCondicionClimatica, int potenciaMaximaCV) {
        super(nombre, ubicacionDelBox, mejorCondicionClimatica);
        this.potenciaMaximaCV = potenciaMaximaCV;
    }

    public int getPotenciaMaximaCV() {
        return potenciaMaximaCV;
    }
    
    @Override
    public void ajustar(){
        System.out.println("Se ajusta el motor");
    }
    
    @Override
    public String toString(){
        return super.toString() + ", potencia maxima en CV: " + potenciaMaximaCV;
    }
}
