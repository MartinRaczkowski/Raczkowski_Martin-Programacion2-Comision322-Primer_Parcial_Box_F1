
package raczkowskimartin_programacion2_div322_primerparcial;


public abstract class Pieza {
    
    private String nombre;
    private String ubicacion;
    private CondicionClimatica mejorClima;

    public Pieza(String nombre, String ubicacion, CondicionClimatica mejorCondicionClimatica) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.mejorClima = mejorCondicionClimatica;
    }

    public String getNombre() {
        return nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public CondicionClimatica getMejorClima() {
        return mejorClima;
    }
    
    @Override
    public String toString(){
        return nombre + ", ubicacion: " + ubicacion + ", mejor condicion climatica:  " + mejorClima;
    }
    
    
    
    
}
