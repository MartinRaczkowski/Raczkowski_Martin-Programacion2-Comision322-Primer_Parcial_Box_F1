
package raczkowskimartin_programacion2_div322_primerparcial;


public enum Compuesto {
    
    SOFT,
    MEDIUM,
    HARD,
    INTERMEDIO,
    WET
    
}
