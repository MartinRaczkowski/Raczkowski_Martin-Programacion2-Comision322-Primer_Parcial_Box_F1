
package recuperatorio_primer_parcial_recital.raczkowski_martin;


public class Solista extends Presentacion implements TocableEnVivo, PublicoAnimable{
    
    private String instrumentoPrincipal;
    private static final String tipoDePresentacion = "Solista";

    public Solista(String instrumentoPrincipal, String nombre, String escenario, TipoDeEscenario tipoDeEscenario) {
        super(nombre, escenario, tipoDeEscenario);
        this.instrumentoPrincipal = instrumentoPrincipal;
    }

    @Override
    public void tocarEnVivo(){
        System.out.println("El/la solista " + getNombre() + " esta tocando en vivo en el escenario " + getEscenario());
    }
    
    @Override
    public void animarPublico(){
        System.out.println("El/la solista " + getNombre() + " esta animando al publico");
    }
    
    @Override
    public String toString(){
        return super.toString() + ", es un/a solista que tiene de instrumento principal: " + instrumentoPrincipal;
    }
    
    @Override
    public String getTipoDePresentacion() {
        return tipoDePresentacion;
    }
    
    
}
