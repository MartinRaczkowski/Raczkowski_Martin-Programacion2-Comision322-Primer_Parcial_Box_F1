
package recuperatorio_primer_parcial_recital.raczkowski_martin;


public class PresentacionDuplicadaException extends Exception{
    
    private static final String MESSAGE = "Presentacion duplicada";

    public PresentacionDuplicadaException() {
        super(MESSAGE);
    }
    
    public String getMESSAGE(){
        return MESSAGE;
    }
    
}
