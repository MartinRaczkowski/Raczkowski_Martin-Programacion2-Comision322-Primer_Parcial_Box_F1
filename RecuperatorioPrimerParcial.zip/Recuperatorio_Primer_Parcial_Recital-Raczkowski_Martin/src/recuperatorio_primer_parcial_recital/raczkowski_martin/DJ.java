
package recuperatorio_primer_parcial_recital.raczkowski_martin;


public class DJ extends Presentacion implements PublicoAnimable{
    
    private String estiloMusicalPredominante;
    private static final String tipoDePresentacion = "DJ";

    public DJ(String estiloMusicalPredominante, String nombre, String escenario, TipoDeEscenario tipoDeEscenario) {
        super(nombre, escenario, tipoDeEscenario);
        this.estiloMusicalPredominante = estiloMusicalPredominante;
    }
    
    @Override
    public void animarPublico(){
        System.out.println("El/la DJ " + getNombre() + " esta animando al publico");
    }
    
    @Override
    public String getTipoDePresentacion() {
        return tipoDePresentacion;
    }
    
}
