package recuperatorio_primer_parcial_recital.raczkowski_martin;

public class Recuperatorio_Primer_Parcial_RecitalRaczkowski_Martin {

    public static void main(String[] args) {
        
        Banda banda1 = new Banda("Los Relampagos", "Escenario principal", TipoDeEscenario.EXTERIOR, 5);
        Banda banda2 = new Banda("Los Truenos", "Escenario secundario", TipoDeEscenario.INTERIOR, 4);
        DJ dj1 = new DJ("House", "Marsh", "Atras", TipoDeEscenario.EXTERIOR);
        Solista solista1 = new Solista("Flauta", "Maria Lopez", "Escenario interior 2", TipoDeEscenario.INTERIOR);
        
        Recital recital = new Recital("Recuperatorio");
        
        try{
            recital.agregarPresentacion(solista1);
            recital.agregarPresentacion(banda1);
            recital.agregarPresentacion(banda2);
            recital.agregarPresentacion(dj1);
            recital.agregarPresentacion(banda1);
        }
        catch(PresentacionDuplicadaException exc){
            System.out.println(exc.getMESSAGE());
        }
        
        recital.animarPublico();
        recital.tocarEnVivo();
        
        recital.filtrarPorTipoDeEscenario(TipoDeEscenario.INTERIOR);
        
        recital.eliminarPresentacionesPorTipo("DJ");
        
    }
    
}
