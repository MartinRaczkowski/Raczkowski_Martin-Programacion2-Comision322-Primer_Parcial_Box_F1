package recuperatorio_primer_parcial_recital.raczkowski_martin;

public class Banda extends Presentacion implements TocableEnVivo{
    
    private int cantIntegrantes;
    private static int cantDeIntegrantesMax = 10;
    private static final String tipoDePresentacion = "Banda";

    public Banda(String nombre, String escenario, TipoDeEscenario tipoDeEscenario, int cantIntegrantes) {
        super(nombre, escenario, tipoDeEscenario);
        if(cantIntegrantes < 2 || cantIntegrantes > cantDeIntegrantesMax){
            throw new IllegalArgumentException("La cantidad de integrantes no esta dentro de los limites establecidos");
        }
        this.cantIntegrantes = cantIntegrantes;
    }
    
    @Override
    public void tocarEnVivo(){
        System.out.println("La banda " + getNombre() + " esta tocando en vivo en el escenario " + getEscenario());
    }
    
    @Override
    public String toString(){
        return super.toString() + ", son una banda con " + cantIntegrantes + " integrantes";
    }

    @Override
    public String getTipoDePresentacion() {
        return tipoDePresentacion;
    }
    
    
}
