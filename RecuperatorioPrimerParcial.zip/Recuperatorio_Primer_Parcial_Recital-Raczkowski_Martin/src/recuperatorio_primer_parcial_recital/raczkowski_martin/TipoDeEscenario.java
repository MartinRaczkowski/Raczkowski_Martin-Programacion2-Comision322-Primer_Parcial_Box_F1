package recuperatorio_primer_parcial_recital.raczkowski_martin;

public enum TipoDeEscenario {
    
    INTERIOR,
    EXTERIOR
     
}
