
package recuperatorio_primer_parcial_recital.raczkowski_martin;

import java.util.ArrayList;


public class Recital {
    
    private String nombre;
    private ArrayList<Presentacion> presentaciones;

    public Recital(String nombre) {
        this.nombre = nombre;
        this.presentaciones = new ArrayList<>();
    }
    
    public void agregarPresentacion(Presentacion presentacion) throws PresentacionDuplicadaException{
        if(presentacion == null){
            throw new IllegalArgumentException();
        }
        if(presentaciones.contains(presentacion)){
            throw new PresentacionDuplicadaException();
        }
        presentaciones.add(presentacion);
        System.out.println("Se agrego la presentacion de " + presentacion);
    }
    
    public void tocarEnVivo(){
        for(Presentacion p : presentaciones){
            if(p instanceof TocableEnVivo tev){
                tev.tocarEnVivo();
            }
        }
    }
    
    public void animarPublico(){
        for(Presentacion p : presentaciones){
            if(p instanceof PublicoAnimable pa){
                pa.animarPublico();
            }
        }
    }
    
    public ArrayList filtrarPorTipoDeEscenario(TipoDeEscenario tipo){
       ArrayList<Presentacion> presentacionesDelTipoSeleccionado = new ArrayList<>();
       for(Presentacion p : presentaciones){
            if(p.getTipoDeEscenario() == tipo){
                presentacionesDelTipoSeleccionado.add(p);
            }
        }
       return presentacionesDelTipoSeleccionado;
    }
    
    public void eliminarPresentacionesPorTipo(String tipoPresentacion){
        ArrayList<Presentacion> presentacionesEliminadas = new ArrayList<>();
        for(Presentacion p : presentaciones){
            if(p.getTipoDePresentacion().equalsIgnoreCase(tipoPresentacion)){
                presentacionesEliminadas.add(p);
            }
        }
        presentaciones.removeAll(presentacionesEliminadas);
    }
    
}
