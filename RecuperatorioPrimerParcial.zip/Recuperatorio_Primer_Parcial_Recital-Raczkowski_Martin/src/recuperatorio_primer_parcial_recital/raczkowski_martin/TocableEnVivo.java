
package recuperatorio_primer_parcial_recital.raczkowski_martin;


public interface TocableEnVivo {
    
    void tocarEnVivo();
    
}
