
package recuperatorio_primer_parcial_recital.raczkowski_martin;

public abstract class Presentacion {
    
    private String nombre;
    private String escenario;
    private TipoDeEscenario tipoDeEscenario;

    public Presentacion(String nombre, String escenario, TipoDeEscenario tipoDeEscenario) {
        this.nombre = nombre;
        this.escenario = escenario;
        this.tipoDeEscenario = tipoDeEscenario;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEscenario() {
        return escenario;
    }

    public TipoDeEscenario getTipoDeEscenario() {
        return tipoDeEscenario;
    }
    
    @Override
    public String toString(){
        return nombre + "toca en el escenario " + escenario + " que es del tipo " + tipoDeEscenario;
    }
    
    public abstract String getTipoDePresentacion();
    
}
