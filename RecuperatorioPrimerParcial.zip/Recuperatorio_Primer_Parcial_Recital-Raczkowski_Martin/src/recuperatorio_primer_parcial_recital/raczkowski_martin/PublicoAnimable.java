
package recuperatorio_primer_parcial_recital.raczkowski_martin;

public interface PublicoAnimable {
    
    void animarPublico();
    
}
